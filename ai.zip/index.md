# Home - Empty IG v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/ig-empty/ImplementationGuide/smart.who.int.ig-empty | *Version*:0.1.0 |
| Draft as of 2025-11-12 | *Computable Name*:IGEmpty |

 This DAK and set of implementation tools are still undergoing development. 

 Content is for demonstration purposes only. 

### Summary

This WHO **[insert health domain here]** DAK **add content here**

### L1 Narrative guidelines

**[insert content here]**

### L2 Operational guidelines

The L2 **[insert health domain here]** Digital adaptation kit publications and implementations tools can be found here:

* [Published DAK Document]()
* [Link to core data dictionary]()
* [Link to decision support logic]()
* [Link to scheduling logic]()
* [Link to indicators table]()
* [Link to functional and non functional requirements]()

### L3 Machine readable guidelines

The L3 FHIR Implementation Guide for the **[insert health domain here]** SMART Guidelines is yet to be published. Links will be published here as soon as they're available.

### L4 Executable guidelines

Reference implementations representing the L4 layer for the **[insert health domain here]** SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### L5 Dynamic guidelines

Content representing the L5 layer for the **[insert health domain here]** SMART Guidelines are not yet available. Links will be published here as soon as they're available.

### News

### Contact Us

Please let us know about your experience in using the DAK and questions you may have by contacting us at [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)

### License

This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 3.0 IGO License](http://creativecommons.org/licenses/by-nc-sa/3.0/igo/).

![](https://i.creativecommons.org/l/by-nc-sa/3.0/igo/88x31.png)

### Providing Feedback

 Feedback specific to this specification can provided through: 

* Clicking on one of the Feedbacks link to the right of any section header
* Sending an email to [SMART@who.int](mailto:SMART@who.int?subject = DAK Feedback)
* Creating an issue on GitHub [ig-empty repository](https://github.com/WorldHealthOrganization/ig-empty)

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.

 This implementation guide and set of artifacts are still undergoing development. 

 Content is for demonstration purposes only. 

### Summary

This implementation guide includes a machine-readable representation of WHO guidelines for **[insert health domain here]**, as documented in the WHO Digital Adaptation Kit for **[insert health domain here]** (link forthcoming) and explicitly encodes computer-interoperable logic, including data models, terminologies, and logic expressions, in a computable language to support implementation of **[insert health domain here]** use cases by WHO Member States.

The guide is part of the [WHO SMART Guidelines approach](https://www.who.int/teams/digital-health-and-innovation/smart-guidelines) to support countries to integrate WHO global health and data recommendations into digital systems accurately and consistently. It defines a series of FHIR Resources, Profiles, Extensions, and Terminology based on the WHO **[insert health domain here]** Digital Adaptation Kit (link forthcoming).

Supporting guidance, recommendations, resources, and standards are included in the [References](references.md) and [Dependencies](dependencies.md).

### About this implementation guide

This implementation guide is broken into the following levels of [knowledge representation](https://hl7.org/fhir/uv/cpg/documentation-approach-06-01-levels-of-knowledge-representation.html):

* [Home](index.md) - contains references to the guidance, guidelines, policies and recommendations underpinning this implementation guide.
* [Business Requirements](business-requirements.md) - contains the requirements for this implementation guide including the definition of key concepts, use cases, and a data dictionary.
* [Data Models and Exchange](data-models-and-exchange.md) - contains the data models and data exchange protocols with actors and transactions defined.
* [Deployment Guidance](deployment.md) - contains relevant technical specifications and guidance, testing resources, reference implementation materials, and supporting guidance for adaptation to local contexts.

This guide is prepared to facilitate digital implementation of WHO **[insert health domain here]** guidelines by providing FHIR-based computable representations of and implementation guidance for using the key components of the WHO **[insert health domain here]** digital adaptation kit (DAK):

* Health Interventions & Recommendations
* Generic Personas
* User Scenarios
* Business Processes & Workflows
* Core Data Elements
* Decision Support Logic
* Indicators & Monitoring
* Functional & Non-functional Requirements

This guide is a companion to the Digital Adaptation Kit (DAK) and should be used side-by-side with it. Implementers are strongly encouraged to make use of the Digital Adaptation Kit. The focus of this guide is on the explanation and use of the computable artifacts.

This guide assumes use of the following resources:

* [IPS Patient](http://hl7.org/fhir/uv/ips/StructureDefinition/Patient-uv-ips)
* [CPG ActivityDefinitions](https://hl7.org/fhir/uv/cpg/artifacts.html#activitydefinition-index)
* For a complete listing of the artifacts defined in this implementation guide, refer to the [Artifact Index](artifacts.md).
* A complete offline copy of this implementation guide can be found on the [Downloads](downloads.md) page.
* This Implementation Guide makes use of [Clinical Quality Language](https://cql.hl7.org/) for the decision support artifacts including the PlanDefinitions and Measures. They are used to express how a calculation should occur and can be used with a CQL engine in order to process the decision or indicator directly from the applicable FHIR resources. Links to this specification, the FHIR Clinical Practice Guidelines Speciciation, and other helpful resources can be found in the Support dropdown.

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.

### Dependencies

### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (smart.who.int.ig-empty.r4)](package.r4.tgz) and [R4B (smart.who.int.ig-empty.r4b)](package.r4b.tgz) are available.

### Global Profiles

*There are no Global profiles defined*

### IP Statements

No use of external IP (other than from the FHIR specification)

